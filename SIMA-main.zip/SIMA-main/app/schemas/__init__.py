# Pydantic Schemas
